using System.Runtime.Versioning;
using MaxterServer.Abstractions;
using MaxterServer.Config;
using MaxterServer.Health;
using MaxterServer.Logging;
using MaxterServer.Net;

namespace MaxterServer.WebServers;

/// <summary>
/// Implementacion de IWebServer sobre Apache httpd + mod_php. Detalle interno del Runtime:
/// el resto del sistema solo ve IWebServer. Genera httpd.conf desde plantilla con rutas
/// absolutas (ServerRoot, DocumentRoot=app/, PHP, Listen 0.0.0.0:puerto) y deja intacto
/// el .htaccess de la aplicacion (AllowOverride All en la plantilla).
/// </summary>
[SupportedOSPlatform("windows")]
public sealed class ApacheWebServer : IWebServer
{
    private readonly RuntimePaths _paths;
    private readonly MaxterConfig _cfg;
    private readonly ComponentInfo _web;
    private readonly ComponentInfo _php;
    private readonly FileLog _log;

    public ApacheWebServer(RuntimePaths paths, MaxterConfig cfg, Manifest manifest, FileLog log)
    {
        _paths = paths;
        _cfg = cfg;
        _web = manifest.Component("web");
        _php = manifest.Component("php");
        _log = log;
    }

    public string Id => "web";
    public string DisplayName => "servidor web";

    public string LocalUrl => $"http://localhost{PortSuffix}";
    public string LanUrl => $"http://{LanAddress.BestGuess()}{PortSuffix}";
    private string PortSuffix => _cfg.Port == 80 ? "" : ":" + _cfg.Port;

    private string TemplatePath => _paths.ComponentFile(_web, "conf/httpd.conf.tmpl");

    public void PrepareConfiguration()
    {
        var tokens = new Dictionary<string, string>
        {
            ["SERVER_ROOT"] = Slash(_paths.ComponentDir(_web)),
            ["DOC_ROOT"]    = Slash(_paths.AppDir(_cfg)),
            ["PORT"]        = _cfg.Port.ToString(),
            ["PHP_DIR"]     = Slash(_paths.ComponentDir(_php)),
        };

        var rendered = TemplateEngine.Render(File.ReadAllText(TemplatePath), tokens);
        Directory.CreateDirectory(_paths.ConfigDir);
        File.WriteAllText(_paths.HttpdConfGenerated, rendered);
        _log.Info("Configuracion del servidor web generada.");
    }

    public ProcessStartSpec BuildStartSpec() => new(
        FileName: _paths.ComponentExecutable(_web),
        Arguments: $"-f \"{_paths.HttpdConfGenerated}\" -d \"{_paths.ComponentDir(_web)}\"",
        WorkingDirectory: _paths.ComponentDir(_web));

    public Task<bool> WaitUntilReadyAsync(TimeSpan timeout) =>
        ReadinessCheck.WaitHttpAsync($"http://127.0.0.1:{_cfg.Port}/", timeout);

    public void RequestGracefulStop()
    {
        // httpd -k stop: apagado ordenado del servidor web
        RunShort(_paths.ComponentExecutable(_web), $"-f \"{_paths.HttpdConfGenerated}\" -k stop");
    }

    private void RunShort(string exe, string args)
    {
        try
        {
            var psi = new System.Diagnostics.ProcessStartInfo(exe, args)
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                WorkingDirectory = _paths.ComponentDir(_web),
            };
            System.Diagnostics.Process.Start(psi);
        }
        catch (Exception ex)
        {
            _log.Error($"No se pudo enviar el apagado ordenado al servidor web: {ex.Message}");
        }
    }

    private static string Slash(string path) => path.Replace('\\', '/');
}
