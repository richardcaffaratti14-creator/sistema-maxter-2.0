namespace MaxterServer;

/// <summary>
/// Resuelve todas las rutas del Runtime a partir de la ubicacion del ejecutable.
/// Al usar rutas relativas al .exe, el producto es portable: se puede mover de carpeta
/// sin reconfigurar. Estructura: config/  runtime/{web,php,db}  app/  logs/.
/// </summary>
public sealed class RuntimePaths
{
    public string Root { get; }

    public RuntimePaths(string? root = null) => Root = root ?? AppContext.BaseDirectory;

    // --- Carpetas de primer nivel ---
    public string ConfigDir => Combine(Root, "config");
    public string RuntimeDir => Combine(Root, "runtime");
    public string LogsDir => Combine(Root, "logs");

    // --- Configuracion (config/) ---
    public string MaxterConfigFile => Combine(ConfigDir, "maxter.config");
    public string HttpdConfGenerated => Combine(ConfigDir, "httpd.generated.conf");
    public string MyIniGenerated => Combine(ConfigDir, "my.generated.ini");

    // --- Manifiesto ---
    public string ManifestFile => Combine(RuntimeDir, "manifest.json");

    // --- Componentes (resueltos via manifiesto) ---
    public string ComponentDir(ComponentInfo c) => Combine(RuntimeDir, c.Path);
    public string ComponentExecutable(ComponentInfo c) => Combine(ComponentDir(c), c.Executable);
    public string ComponentFile(ComponentInfo c, string relative) => Combine(ComponentDir(c), relative);

    // --- Aplicacion publicada ---
    public string AppDir(MaxterConfig cfg) => Combine(Root, cfg.AppFolder);

    private static string Combine(params string[] parts) => Path.Combine(parts);
}
